#bin/bash
gnome-terminal --window -x bash -c "java -jar scripts/DHT2021.jar; exec bash"



